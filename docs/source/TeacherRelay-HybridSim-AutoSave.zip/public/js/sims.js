// TeacherRelay Multi-Engine Physics Router
import { HybridEngines } from './hybrid-lab.js';

export function renderSim(sim, opt = {}) {
  const root = document.createElement('div');
  root.className = 'sim-hybrid-container relative w-full h-full min-h-[340px] bg-slate-950 rounded-xl overflow-hidden';

  const cfg = sim?.config || sim || {};
  const text = `${sim?.label || ''} ${sim?.title || ''} ${cfg?.type || ''}`.toLowerCase();

  // 自動ハイブリッドルーティング
  setTimeout(() => {
    if (text.includes('orbit') || text.includes('宇宙') || text.includes('惑星') || text.includes('太陽系') || text.includes('脱出')) {
      HybridEngines.mountOrbit3D(root, cfg);
    } else if (text.includes('cannon') || text.includes('剛体') || text.includes('衝突') || text.includes('ドミノ') || text.includes('坂')) {
      HybridEngines.mountCannon3D(root, cfg);
    } else if (text.includes('circuit') || text.includes('回路') || text.includes('直列') || text.includes('並列') || text.includes('豆電球') || text.includes('電気')) {
      HybridEngines.mountCircuit(root, cfg);
    } else if (text.includes('wave') || text.includes('波') || text.includes('音') || text.includes('光') || text.includes('ドップラー') || text.includes('速さ')) {
      HybridEngines.mountWave2D(root, cfg);
    } else if (text.includes('fluid') || text.includes('浮力') || text.includes('アルキメデス') || text.includes('船') || text.includes('密度')) {
      HybridEngines.mountFluid(root, cfg);
    } else {
      HybridEngines.mountCannon3D(root, cfg);
    }
  }, 10);

  return root;
}
