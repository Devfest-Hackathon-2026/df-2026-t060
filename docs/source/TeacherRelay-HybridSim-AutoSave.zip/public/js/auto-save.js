// TeacherRelay 自動保存・自動復元マネージャー
(function initAutoSave() {
  const STORAGE_KEY = 'teacher_relay_lesson_draft_v1';
  const targetSelectors = ['#sampleTopic', '#lessonTitle', '#lessonIntro', '#questionFlow', '#hypothesisFlow', '#verifyFlow', '#summaryFlow'];

  // 入力内容のローカルストレージ自動保存 (入力後500msのデバウンス)
  let saveTimer = null;
  function triggerSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      const draft = {};
      targetSelectors.forEach(sel => {
        const el = document.querySelector(sel);
        if (el) draft[sel] = el.value;
      });
      const simSelect = document.querySelector('#sampleSim');
      if (simSelect) draft['#sampleSim'] = simSelect.value;

      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        updatedAt: new Date().toISOString(),
        draft
      }));
      showSaveBadge('自動保存済み');
    }, 500);
  }

  // 画面ロード時の自動復元
  window.addEventListener('DOMContentLoaded', () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (data.draft) {
          Object.entries(data.draft).forEach(([sel, val]) => {
            const el = document.querySelector(sel);
            if (el && !el.value && val) {
              el.value = val;
            }
          });
          showSaveBadge('前回の入力を復元しました');
        }
      }
    } catch (e) {
      console.warn('AutoSave復元エラー:', e);
    }

    // イベントリスナーの登録
    document.addEventListener('input', (e) => {
      if (e.target.matches('input, textarea, select')) {
        triggerSave();
      }
    });
    document.addEventListener('change', (e) => {
      if (e.target.matches('select')) {
        triggerSave();
      }
    });
  });

  // UI上の保存バッジ通知
  function showSaveBadge(text) {
    let badge = document.getElementById('auto-save-status-badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.id = 'auto-save-status-badge';
      badge.className = 'fixed bottom-4 right-4 z-50 px-3 py-1.5 rounded-lg bg-slate-900/90 text-sky-300 border border-sky-500/30 text-xs shadow-lg pointer-events-none transition-opacity duration-300 opacity-0';
      document.body.appendChild(badge);
    }
    badge.textContent = `💾 ${text}`;
    badge.style.opacity = '1';
    setTimeout(() => { badge.style.opacity = '0'; }, 2200);
  }
})();
