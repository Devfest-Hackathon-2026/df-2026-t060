// TeacherRelay Multi-Engine Physics Lab (Three.js / Cannon.js / Canvas2D)

export const HybridEngines = {
  // 1. 3D太陽系・万有引力・宇宙速度
  mountOrbit3D(container, config = {}) {
    container.innerHTML = '';
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x02040a);

    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 4000);
    camera.position.set(0, 80, 150);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const sunLight = new THREE.PointLight(0xfff7ed, 3, 2000);
    scene.add(sunLight);

    // 太陽
    const sun = new THREE.Mesh(new THREE.SphereGeometry(7, 32, 32), new THREE.MeshBasicMaterial({ color: 0xffb703 }));
    scene.add(sun);

    // 地球 & 月
    const earthOrbitR = 36;
    const earth = new THREE.Mesh(new THREE.SphereGeometry(2, 24, 24), new THREE.MeshStandardMaterial({ color: 0x38bdf8 }));
    scene.add(earth);

    // 軌道線
    const pts = new THREE.EllipseCurve(0, 0, earthOrbitR, earthOrbitR, 0, Math.PI * 2).getPoints(64).map(p => new THREE.Vector3(p.x, 0, p.y));
    scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x334155 })));

    // 探査機 (第1・第2・第3宇宙速度)
    const probes = [];
    const colors = [0x38bdf8, 0x22c55e, 0xf43f5e];
    for (let i = 1; i <= 3; i++) {
      const pMesh = new THREE.Mesh(new THREE.SphereGeometry(0.7, 16, 16), new THREE.MeshBasicMaterial({ color: colors[i-1] }));
      scene.add(pMesh);
      probes.push({ mesh: pMesh, type: i, angle: 0, r: earthOrbitR, vel: i === 1 ? 0.3 : i === 2 ? 0.45 : 0.75, dist: 0 });
    }

    let th = 0, rafId = null;
    function loop() {
      rafId = requestAnimationFrame(loop);
      th += 0.015;
      earth.position.set(Math.cos(th) * earthOrbitR, 0, Math.sin(th) * earthOrbitR);

      probes.forEach(pb => {
        if (pb.type === 1) {
          // 第1: 地球周回
          pb.angle += 0.08;
          pb.mesh.position.set(earth.position.x + Math.cos(pb.angle) * 4, 0, earth.position.z + Math.sin(pb.angle) * 4);
        } else if (pb.type === 2) {
          // 第2: 太陽周回楕円
          pb.angle += 0.01;
          const r = earthOrbitR + Math.sin(pb.angle) * 22;
          pb.mesh.position.set(Math.cos(pb.angle + th) * r, 0, Math.sin(pb.angle + th) * r);
        } else {
          // 第3: 太陽系脱出 (双曲線)
          pb.dist += 0.35;
          pb.mesh.position.set(earth.position.x + pb.dist * 0.8, pb.dist * 0.2, earth.position.z + pb.dist * 1.2);
        }
      });

      camera.lookAt(earth.position);
      renderer.render(scene, camera);
    }
    loop();

    return { dispose() { cancelAnimationFrame(rafId); renderer.dispose(); container.innerHTML = ''; } };
  },

  // 2. 3D剛体物理・衝突・ドミノ (Cannon-es / Three.js)
  mountCannon3D(container, config = {}) {
    container.innerHTML = '';
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x060a12);

    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 16, 32);
    camera.lookAt(0, 3, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const light = new THREE.DirectionalLight(0xffffff, 1.2);
    light.position.set(15, 30, 20);
    scene.add(light);
    scene.add(new THREE.GridHelper(60, 60, 0x38bdf8, 0x1e293b));

    const world = new CANNON.World();
    world.gravity.set(0, -9.82, 0);
    const ground = new CANNON.Body({ mass: 0, shape: new CANNON.Plane() });
    ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
    world.addBody(ground);

    const synced = [];
    // スロープ
    const slopeMesh = new THREE.Mesh(new THREE.BoxGeometry(10, 0.5, 5), new THREE.MeshStandardMaterial({ color: 0x334155 }));
    const slopeBody = new CANNON.Body({ mass: 0, shape: new CANNON.Box(new CANNON.Vec3(5, 0.25, 2.5)), position: new CANNON.Vec3(-7, 5, 0) });
    slopeBody.quaternion.setFromEuler(0, 0, -0.35);
    scene.add(slopeMesh); world.addBody(slopeBody); synced.push({ mesh: slopeMesh, body: slopeBody });

    // ドミノ群
    for (let i = 0; i < 8; i++) {
      const dm = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3.6, 2.4), new THREE.MeshStandardMaterial({ color: 0xf43f5e }));
      const db = new CANNON.Body({ mass: 2, shape: new CANNON.Box(new CANNON.Vec3(0.2, 1.8, 1.2)), position: new CANNON.Vec3(-0.5 + i * 1.5, 1.8, 0) });
      scene.add(dm); world.addBody(db); synced.push({ mesh: dm, body: db });
    }

    // 転がるボール群
    for (let i = 0; i < 12; i++) {
      const r = 0.6;
      const bm = new THREE.Mesh(new THREE.SphereGeometry(r, 20, 20), new THREE.MeshStandardMaterial({ color: 0x38bdf8 }));
      const bb = new CANNON.Body({ mass: 2.5, shape: new CANNON.Sphere(r), position: new CANNON.Vec3(-10 + (i % 3) * 1.2, 8 + Math.floor(i / 3) * 1.5, (i % 2) * 1.2) });
      scene.add(bm); world.addBody(bb); synced.push({ mesh: bm, body: bb });
    }

    let rafId = null;
    function loop() {
      rafId = requestAnimationFrame(loop);
      world.step(1 / 60);
      synced.forEach(s => {
        s.mesh.position.copy(s.body.position);
        s.mesh.quaternion.copy(s.body.quaternion);
      });
      renderer.render(scene, camera);
    }
    loop();

    return { dispose() { cancelAnimationFrame(rafId); renderer.dispose(); container.innerHTML = ''; } };
  },

  // 3. 電気・回路網 (電子流動・直列並列・電球発光)
  mountCircuit(container, config = {}) {
    container.innerHTML = '';
    const canvas = document.createElement('canvas');
    canvas.width = container.clientWidth || 640;
    canvas.height = 340;
    canvas.style.width = '100%';
    canvas.style.display = 'block';
    container.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    let mode = config.circuitMode || 'series';
    let v = config.voltage || 9.0;
    let bulbs = config.bulbCount || 2;
    let sw = true, t = 0, rafId = null;

    canvas.onclick = () => { sw = !sw; };

    function loop() {
      rafId = requestAnimationFrame(loop);
      t += 0.02;
      ctx.fillStyle = '#060a12';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const cx = canvas.width / 2, cy = canvas.height / 2;
      const w = Math.min(500, canvas.width * 0.7), h = 180;
      const left = cx - w/2, right = cx + w/2, top = cy - h/2, bottom = cy + h/2;

      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 4;
      ctx.strokeRect(left, top, w, h);

      // 電池
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(left - 12, cy - 20, 24, 40);
      ctx.fillStyle = '#fff';
      ctx.font = '11px monospace';
      ctx.fillText(`${v}V`, left - 35, cy + 4);

      // 電流計算
      const current = sw ? (mode === 'series' ? v / (bulbs * 5) : (v / 5) * bulbs) : 0;

      // 電子の流動
      if (sw && current > 0) {
        ctx.fillStyle = '#38bdf8';
        const numE = 20;
        for (let i = 0; i < numE; i++) {
          const off = (t * current * 40 + i * 40) % (w * 2 + h * 2);
          let ex = 0, ey = 0;
          if (off < w) { ex = left + off; ey = top; }
          else if (off < w + h) { ex = right; ey = top + (off - w); }
          else if (off < w * 2 + h) { ex = right - (off - (w + h)); ey = bottom; }
          else { ex = left; ey = bottom - (off - (w * 2 + h)); }
          ctx.beginPath(); ctx.arc(ex, ey, 3.5, 0, Math.PI * 2); ctx.fill();
        }
      }

      // 豆電球描画
      const step = w / (bulbs + 1);
      for (let i = 1; i <= bulbs; i++) {
        const bx = left + i * step, by = bottom;
        if (sw && current > 0) {
          const grad = ctx.createRadialGradient(bx, by, 3, bx, by, 25);
          grad.addColorStop(0, 'rgba(254, 240, 138, 0.9)');
          grad.addColorStop(1, 'rgba(250, 204, 21, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath(); ctx.arc(bx, by, 25, 0, Math.PI * 2); ctx.fill();
        }
        ctx.fillStyle = '#0f172a'; ctx.strokeStyle = sw ? '#fde047' : '#64748b'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(bx, by, 12, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      }

      // スイッチ表示
      ctx.strokeStyle = sw ? '#22c55e' : '#ef4444'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(cx - 15, top); ctx.lineTo(cx + (sw ? 15 : 10), top - (sw ? 0 : 16)); ctx.stroke();
      ctx.fillStyle = sw ? '#4ade80' : '#f87171'; ctx.font = '11px sans-serif';
      ctx.fillText(sw ? 'スイッチ: ON (クリックでOFF)' : 'スイッチ: OFF (クリックで通電)', cx - 80, top - 24);
    }
    loop();

    return { dispose() { cancelAnimationFrame(rafId); container.innerHTML = ''; } };
  },

  // 4. 波動・光・音 (ドップラー & 音速光速伝播)
  mountWave2D(container, config = {}) {
    container.innerHTML = '';
    const canvas = document.createElement('canvas');
    canvas.width = container.clientWidth || 640;
    canvas.height = 340;
    canvas.style.width = '100%';
    canvas.style.display = 'block';
    container.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    const waves = [];
    let sx = 60, timer = 0, rafId = null;
    const mach = config.mach || 1.1;

    function loop() {
      rafId = requestAnimationFrame(loop);
      ctx.fillStyle = '#060a12';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const cy = canvas.height / 2;
      sx += 2.2 * mach;
      if (sx > canvas.width + 50) { sx = -20; waves.length = 0; }

      timer++;
      if (timer % 8 === 0) waves.push({ x: sx, y: cy, r: 0 });

      for (let i = waves.length - 1; i >= 0; i--) {
        const w = waves[i];
        w.r += 2.2;
        ctx.strokeStyle = mach >= 1.0 ? 'rgba(56, 189, 248, 0.5)' : 'rgba(16, 185, 129, 0.6)';
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, Math.PI * 2); ctx.stroke();
        if (w.r > canvas.width * 1.2) waves.splice(i, 1);
      }

      ctx.fillStyle = '#f43f5e';
      ctx.beginPath(); ctx.arc(sx, cy, 6, 0, Math.PI * 2); ctx.fill();
    }
    loop();

    return { dispose() { cancelAnimationFrame(rafId); container.innerHTML = ''; } };
  },

  // 5. 流体・浮力 (アルキメデスの原理・ベクトル)
  mountFluid(container, config = {}) {
    container.innerHTML = '';
    const canvas = document.createElement('canvas');
    canvas.width = container.clientWidth || 640;
    canvas.height = 340;
    canvas.style.width = '100%';
    canvas.style.display = 'block';
    container.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    let blockY = 120, vy = 0, phase = 0, rafId = null;
    const rhoObj = config.objectDensity || 0.65; // 木材: 0.65 (浮く), 鉄: 1.4 (沈む)

    function loop() {
      rafId = requestAnimationFrame(loop);
      phase += 0.04;
      ctx.fillStyle = '#060a12';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const wl = canvas.height * 0.55;
      const bw = 90, bh = 90, bx = canvas.width / 2 - bw / 2;

      // 物理計算
      const submerged = Math.max(0, Math.min(bh, (blockY + bh) - wl));
      const fb = (submerged / bh) * 1.0 * 9.8;
      const fg = rhoObj * 9.8;
      vy += (fb - fg) * 0.015;
      vy *= 0.95;
      blockY -= vy;
      if (blockY > canvas.height - bh - 10) { blockY = canvas.height - bh - 10; vy = 0; }

      // 水面
      ctx.fillStyle = 'rgba(14, 165, 233, 0.35)';
      ctx.beginPath(); ctx.moveTo(0, wl);
      for (let x = 0; x <= canvas.width; x += 15) ctx.lineTo(x, wl + Math.sin(x * 0.02 + phase) * 3);
      ctx.lineTo(canvas.width, canvas.height); ctx.lineTo(0, canvas.height); ctx.fill();

      // 物体
      ctx.fillStyle = rhoObj < 1.0 ? '#e2e8f0' : '#475569';
      ctx.fillRect(bx, blockY, bw, bh);
      ctx.strokeStyle = '#94a3b8'; ctx.strokeRect(bx, blockY, bw, bh);

      // ベクトル矢印
      const cx = canvas.width / 2, cy = blockY + bh / 2;
      ctx.strokeStyle = '#f43f5e'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx, cy + 45); ctx.stroke();
      ctx.fillStyle = '#f43f5e'; ctx.font = '10px monospace'; ctx.fillText('重力 Fg', cx + 8, cy + 40);

      const fbLen = (submerged / bh) * (1.0 / rhoObj) * 45;
      if (fbLen > 2) {
        ctx.strokeStyle = '#22c55e';
        ctx.beginPath(); ctx.moveTo(cx - 10, cy); ctx.lineTo(cx - 10, cy - fbLen); ctx.stroke();
        ctx.fillStyle = '#22c55e'; ctx.fillText('浮力 Fb', cx - 75, cy - fbLen + 10);
      }
    }
    loop();

    return { dispose() { cancelAnimationFrame(rafId); container.innerHTML = ''; } };
  }
};
