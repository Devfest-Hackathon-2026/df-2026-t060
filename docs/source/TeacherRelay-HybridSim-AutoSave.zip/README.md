# TeacherRelay 5大物理シミュレーション & 自動保存モジュール

## 概要
- **5大特化型物理エンジン**:
  1. `orbit3d`: 3D太陽系・万有引力・第1〜第3宇宙速度
  2. `cannon3d`: Three.js + Cannon-es 3D剛体物理・衝突・ドミノ
  3. `circuit`: 電気回路網・直列並列・電子流動アニメーション
  4. `wave2d`: 波動・光学・音速光速・ドップラー効果
  5. `fluid`: 流体・浮力・アルキメデスの原理・ベクトル表示
- **自動保存 (Auto-Save)**:
  先生画面で作成中の教材（要望、題名、導入、授業の流れなど）を入力と同時に自動でLocalStorageにバックアップし、リロード時や不意の切断時にも自動復元します。

## 導入手順
1. 本zipの内容を展開し、プロジェクトルート（`C:\dev\hakkason`）の `public/` フォルダに上書き配置します。
2. `public/teacher.html` および `public/student.html` の `<head>` 内に以下を追加します：
   ```html
   <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/cannon.js/0.6.2/cannon.min.js"></script>
   <script src="js/auto-save.js"></script>
   ```
3. サーバーを起動またはデプロイします：
   - ローカル: `node server/index.js`
   - Firebase本番: `cmd.exe /c "firebase deploy --only hosting"`
