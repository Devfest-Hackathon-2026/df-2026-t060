﻿#requires -Version 5.1
$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "ふしぎ教室 Gemma 4 一括セットアップ"

function Say($message, $color = "Cyan") {
    Write-Host "`n$message" -ForegroundColor $color
}

$root = $PSScriptRoot
$project = Join-Path $root "fushigi-classroom-final"
$server = Join-Path $project "server"
$publicUrl = "https://kyoiku-hakkason--demo-share-yupfa3zo.web.app/demo.html?demo"
$origin = "https://kyoiku-hakkason--demo-share-yupfa3zo.web.app"
$origins = "$origin,https://kyoiku-hakkason.web.app,https://kyoiku-hakkason.firebaseapp.com,http://localhost:5000,http://127.0.0.1:5000,http://localhost:8001,http://127.0.0.1:8001"

try {
    Say "1/6  ファイルを確認しています"
    if (!(Test-Path (Join-Path $project "firebase.json")) -or !(Test-Path (Join-Path $server "package.json"))) {
        throw "ZIPの展開場所が正しくありません。セットアップ.ps1と fushigi-classroom-final フォルダを同じ場所に置いてください。"
    }
    if (!(Get-Command node.exe -ErrorAction SilentlyContinue)) { throw "Node.js が見つかりません。Node.jsをインストールしてから再実行してください。" }
    if (!(Get-Command firebase.cmd -ErrorAction SilentlyContinue)) { throw "Firebase CLI が見つかりません。firebase-toolsをインストールしてから再実行してください。" }
    if (!(Get-Command ollama.exe -ErrorAction SilentlyContinue)) { throw "Ollama が見つかりません。Ollamaをインストールしてから再実行してください。" }

    $busy = Get-NetTCPConnection -LocalPort 8787 -State Listen -ErrorAction SilentlyContinue
    if ($busy) { throw "8787番ポートが既に使用中です。古いAIサーバーのPowerShell画面で Ctrl+C を押して停止し、このスクリプトを再実行してください。" }

    Say "2/6  Ollama と Gemma 4 を確認しています"
    try { $tags = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/tags" -TimeoutSec 3 }
    catch {
        Say "Ollamaを起動します"
        $ollamaCommand = "ollama serve"
        Start-Process -FilePath "powershell.exe" -ArgumentList "-NoExit -ExecutionPolicy Bypass -Command `"$ollamaCommand`""
        $tags = $null
        for ($i = 0; $i -lt 20; $i++) {
            Start-Sleep -Seconds 2
            try { $tags = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/tags" -TimeoutSec 3; break } catch {}
        }
        if (!$tags) { throw "Ollamaを起動できませんでした。Ollamaアプリを起動してから再実行してください。" }
    }
    $names = @($tags.models | ForEach-Object { $_.name })
    if ($names -contains "gemma4:12b") { $model = "gemma4:12b" }
    elseif ($names -contains "gemma4:e4b") { $model = "gemma4:e4b" }
    else { throw "Gemma 4が見つかりません。ollama listでモデルを確認してください。gemma4:12b または gemma4:e4b が必要です。" }
    Write-Host "使用モデル: $model" -ForegroundColor Green

    Say "3/6  AIサーバーの依存関係を準備しています"
    Push-Location $server
    try {
        & npm.cmd install
        if ($LASTEXITCODE -ne 0) { throw "npm install に失敗しました。" }
    } finally { Pop-Location }

    Say "4/6  Firebaseへ公開します"
    Push-Location $project
    try {
        & firebase.cmd hosting:channel:deploy demo-share --project kyoiku-hakkason
        if ($LASTEXITCODE -ne 0) { throw "Firebaseへの公開に失敗しました。firebase login とプロジェクト権限を確認してください。" }
    } finally { Pop-Location }

    Say "5/6  Gemma 4接続サーバーを起動します"
    $serverCommand = "Set-Location -LiteralPath '$server'; `$env:RELAY='0'; `$env:LLM_MODEL='$model'; `$env:ALLOWED_ORIGINS='$origins'; npm.cmd start"
    Start-Process -FilePath "powershell.exe" -ArgumentList "-NoExit -ExecutionPolicy Bypass -Command `"$serverCommand`""

    $ready = $false
    for ($i = 0; $i -lt 20; $i++) {
        Start-Sleep -Seconds 2
        try {
            $health = Invoke-RestMethod -Uri "http://localhost:8787/health" -TimeoutSec 2
            $ready = $true
            break
        } catch {}
    }
    if (!$ready) { throw "AIサーバーの起動を確認できませんでした。新しく開いたサーバー画面のエラーを確認してください。" }

    Say "6/6  公開デモを開きます"
    Start-Process $publicUrl
    Write-Host "`nセットアップが完了しました。" -ForegroundColor Green
    Write-Host "公開デモ: $publicUrl"
    Write-Host "AIサーバー: http://localhost:8787"
    Write-Host "サーバーを使う間は、新しく開いたAIサーバーのPowerShell画面を閉じないでください。"
}
catch {
    Write-Host "`nセットアップを中断しました: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "表示された原因を解消してから、もう一度このスクリプトを実行してください。" -ForegroundColor Yellow
}
finally {
    Write-Host "`nEnterキーでこの画面を閉じます。"
    [void](Read-Host)
}
