﻿# 生徒側・教材側JSに混入した不要コードの一括クリーンアップ
$publicDir = "C:\dev\fushigi-classroom-gemma4-one-click-fixed\fushigi-classroom-final\public"

Write-Host "=== クリーンアップを開始します ===" -ForegroundColor Cyan

Get-ChildItem -Path $publicDir -Recurse -Filter "*.js" -File | ForEach-Object {
    $content = Get-Content $_.FullName -Raw -Encoding UTF8
    if ($content -match "// === \[Auto-Injected\]") {
        $cleaned = $content -replace "(?s)\r?\n// === \[Auto-Injected\].*$", ""
        Set-Content -Path $_.FullName -Value $cleaned -Encoding UTF8
        Write-Host "クリーンアップ完了: $($_.Name)" -ForegroundColor Green
    }
}

Write-Host "`nすべてのJSファイルの修復が完了しました！" -ForegroundColor Cyan
Write-Host "先生PCのブラウザで http://localhost:8787/teacher.html を開いて動作を確認してください。" -ForegroundColor Yellow
