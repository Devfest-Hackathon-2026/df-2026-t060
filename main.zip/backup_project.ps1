﻿# プロジェクトの安全なZIPバックアップスクリプト
Add-Type -AssemblyName System.IO.Compression.FileSystem

$sourceDir = "C:\dev\fushigi-classroom-gemma4-one-click-fixed"
$zipPath   = "C:\dev\fushigi-classroom-backup.zip"

Write-Host "=== プロジェクトのバックアップを開始します ===" -ForegroundColor Cyan

if (Test-Path $zipPath) { 
    Remove-Item $zipPath -Force 
}

$zip = [System.IO.Compression.ZipFile]::Open($zipPath, 'Create')

# bin, obj, node_modules, .git を除外して追加（ファイルロック回避 & 容量軽量化）
Get-ChildItem -Path $sourceDir -Recurse -File | Where-Object {
    $_.FullName -notmatch '\\(bin|obj|node_modules|\.git)\\'
} | ForEach-Object {
    $relPath = $_.FullName.Substring($sourceDir.Length + 1)
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $relPath)
}

$zip.Dispose()
Write-Host "バックアップが完了しました: $zipPath" -ForegroundColor Green
