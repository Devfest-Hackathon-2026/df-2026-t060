﻿【不思議教室 復旧・バックアップ手順】

1. cleanup_and_fix.ps1
   生徒側・教材側のJavaScriptファイルから誤って追記された不要コードを削除・復旧します。
   実行方法:
   PowerShellで右クリック「PowerShellで実行」、またはコンソールで:
   powershell -ExecutionPolicy Bypass -File .\cleanup_and_fix.ps1

2. backup_project.ps1
   TeacherRelayなどの起動中プロセスが掴んでいるDLLや巨大なキャッシュ（bin, obj, node_modules）を
   自動的にスキップし、エラーを出さずに C:\dev\fushigi-classroom-backup.zip を作成します。
   実行方法:
   PowerShellで右クリック「PowerShellで実行」、またはコンソールで:
   powershell -ExecutionPolicy Bypass -File .\backup_project.ps1

3. 動作確認
   サーバー起動後、先生側ブラウザで以下のURLを開いてください:
   http://localhost:8787/teacher.html
